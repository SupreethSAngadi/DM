# Loading libraries
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import numpy as np # linear algebra
from matplotlib import pyplot as plt

#Import models from scikit learn module:
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn import metrics
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold   #For K-fold cross validation
from sklearn.tree import DecisionTreeClassifier, export_graphviz
import seaborn as sns

# loading the raw data
bc=pd.read_csv("C:\\Users\\Manasa\\Desktop\\data.csv")
print(bc.head())

# clean and prepare the data
bc.drop('id',axis=1,inplace=True)
#bc.drop('Unnamed: 32',axis=1,inplace=True)

# size of the dataframe
print(len(bc))

bc.diagnosis.unique()
bc['diagnosis'] = bc['diagnosis'].map({'M':1,'B':0})
print(bc.head())

# explore the data
bc.describe()
plt.hist(bc['diagnosis'])
plt.title('Diagnosis (M=1 , B=0)')
plt.show()

# nucleus features vs diagnosis
features_mean=list(bc.columns[1:11])
# split dataframe into two based on diagnosis
bcM=bc[bc['diagnosis'] ==1]
bcB=bc[bc['diagnosis'] ==0]
#Stack the data
plt.rcParams.update({'font.size': 8})
fig, axes = plt.subplots(nrows=5, ncols=2, figsize=(8,10))
axes = axes.ravel()
for idx,ax in enumerate(axes):
    ax.figure
    binwidth= (max(bc[features_mean[idx]]) - min(bc[features_mean[idx]]))/50
    ax.hist([bcM[features_mean[idx]],bcB[features_mean[idx]]], bins=np.arange(min(bc[features_mean[idx]]), max(bc[features_mean[idx]]) + binwidth, binwidth) , alpha=0.5,stacked=True, normed = True, label=['M','B'],color=['r','g'])
    ax.legend(loc='upper right')
    ax.set_title(features_mean[idx])
plt.tight_layout()
plt.show()

# creating test set and training set
traindf, testdf = train_test_split(bc, test_size = 0.3)

# Generic function for making a classification model and accessing the performance.
def classification_model(model, data, predictors, outcome):
    # Fit the model:
    model.fit(data[predictors], data[outcome])

    # Make predictions on training set:
    predictions = model.predict(data[predictors])

    # Print accuracy
    accuracy = metrics.accuracy_score(predictions, data[outcome])
    print("Accuracy is %s" % "{0:.3%}".format(accuracy))


    # Fit the model again so that it can be refered outside the function:
    model.fit(data[predictors], data[outcome])

    return model,accuracy

#k-nearesr neighbour
k_range=list(range(5,50))
k_accuracy=[]
print("KNN:")
for k in k_range:
    predictor_var = features_mean
    outcome_var = 'diagnosis'
    model = KNeighborsClassifier(n_neighbors=k)
    print("k value %d:"%(k),end='')
    m,accuracy=classification_model(model, traindf, predictor_var, outcome_var)
    k_accuracy.append(accuracy)

from matplotlib import pyplot as plt
plt.plot(k_range,k_accuracy,color="red")
plt.xlabel('k values')
plt.ylabel('Accuracy')
plt.show()

#Logistic regression
predictor_var = features_mean
outcome_var = 'diagnosis'
model = LogisticRegression()
print("Logistic regression:",end='')
classification_model(model, traindf, predictor_var, outcome_var)

#Decision-tree
predictor_var = features_mean
outcome_var = 'diagnosis'
model = DecisionTreeClassifier()
print("DecisionTreeClassification:",end='')
classification_model(model, traindf, predictor_var, outcome_var)

predictor_var = ['radius_mean']
outcome_var = 'diagnosis'
model = DecisionTreeClassifier()
print("DecisionTreeClassifier with one feature:",end='')
classification_model(model,traindf,predictor_var,outcome_var)
